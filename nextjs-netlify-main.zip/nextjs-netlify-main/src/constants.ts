export const DEFAULT_PAGE_SIZE = 15;

export const REDIS_RECIPE_STATS_KEY = 'recipe-stats';
