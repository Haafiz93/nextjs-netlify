---
name: 💡 Feature suggestion
about: What would make this even better?
---

# What is currently missing?

<!-- Please, describe what is currently missing and why should it be present in the project. -->

# How could this be improved?

<!-- If you already know how this could be approached, please provide some brief explanation about it. -->

# Is this a feature you would work on yourself?

* [ ] I plan to open a pull request for this feature
