---
name: 🐜 Report a bug
about: Spotted a problem? Let us know
---

# What happened?

<!-- Try to be as precise as possible. If you can a small reproducer example would be great! -->

# What did you expect to happen?

<!-- Please explain what would be the expected behavior for this particular case, ideally, with examples. -->

# What else do we need to know?

<!-- Include your platform, version, and any other information that seems relevant. -->

